package com.dev.store.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dev.store.models.InItem;
import com.dev.store.repositories.InItemRepositories;
import com.dev.store.service.ReportServiceStock;
import net.sf.jasperreports.engine.JRException;

@SpringBootApplication
@RestController
public class StoreStockController {
	
	@Autowired
	private InItemRepositories inItemRepositories;
	
	@Autowired
	private ReportServiceStock service;
	
	@GetMapping("/api/admin/getStock")
	public List<InItem> getStock(){
		return inItemRepositories.findAll();
	}

	@GetMapping("/api/admin/in/{format}")
	public String generateReport(@PathVariable String format)  throws FileNotFoundException, JRException{
		return service.exportReport(format);
	}
	


}
