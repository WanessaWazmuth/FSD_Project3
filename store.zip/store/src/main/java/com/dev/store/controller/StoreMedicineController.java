package com.dev.store.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dev.store.models.Medicine;
import com.dev.store.repositories.MedicineRepositories;
import com.dev.store.service.ReportServiceMedicine;
import net.sf.jasperreports.engine.JRException;

@SpringBootApplication
@RestController
public class StoreMedicineController {
	
	@Autowired
	private MedicineRepositories medicineRepositories;
	
	@Autowired
	private ReportServiceMedicine service;
	
	@GetMapping("/api/admin/getMedicine")
	public List<Medicine> getMedicine(){
		return medicineRepositories.findAll();
	}

	@GetMapping("/api/admin/medicine/{format}")
	public String generateReport(@PathVariable String format)  throws FileNotFoundException, JRException{
		return service.exportReport(format);
	}
	


}
