package com.dev.store.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.Client;
import com.dev.store.models.Account;
import com.dev.store.models.Buy;
import com.dev.store.models.ItemBuy;
import com.dev.store.models.Medicine;
import com.dev.store.repositories.ClientRepositories;
import com.dev.store.repositories.BuyRepositories;
import com.dev.store.repositories.ItemBuyRepositories;
import com.dev.store.repositories.MedicineRepositories;

@Controller
public class CartController {

	
	private List<ItemBuy> itemBuy = new ArrayList<ItemBuy>();
	
	private Buy buy = new Buy();
	
	
	private Client client;
	
	private Account account;

	@Autowired
	private MedicineRepositories repositorioMedicine;

	@Autowired
	private ClientRepositories repositorioClient;

	@Autowired
	private BuyRepositories repositorioBuy;

	@Autowired
	private ItemBuyRepositories repositorioItemBuy;
	

	private void calcTotal() {
		buy.setValueTotal(0.);
		for (ItemBuy it : itemBuy) {
			buy.setValueTotal(buy.getValueTotal() + it.getValueTotal());
		}
	}

	@GetMapping("/api/cart")
	public ModelAndView callCart() {
		ModelAndView mv = new ModelAndView("api/user/cart");
		calcTotal();
		mv.addObject("buy", buy);
		mv.addObject("listItem", itemBuy);
		return mv;
	}

	private void searchUserLogin() {
		Authentication Authenticated = SecurityContextHolder.getContext().getAuthentication();
		if (!(Authenticated instanceof AnonymousAuthenticationToken)) {
			String email = Authenticated.getName();
			client = repositorioClient.searchClientEmail(email).get(0);
		}
	}

	@GetMapping("/api/checkout")
	public ModelAndView checkoutBuy() {
		searchUserLogin();
		ModelAndView mv = new ModelAndView("api/user/checkout");
		calcTotal();
		mv.addObject("buy", buy);
		mv.addObject("listItem", itemBuy);
		mv.addObject("client", client);
		mv.addObject("account", account);
		return mv;
	}

	@PostMapping("/api/checkout/confirme")
	public ModelAndView confirmeBuy(String payment) {
		ModelAndView mv = new ModelAndView("api/user/messageFinished");	
		ModelAndView mv2 = new ModelAndView("api/user/messageFund");
		buy.setClient(client);
		buy.setPayment(payment);
		if(client.getFunds() >= buy.getValueTotal()) {
			
		for (ItemBuy c : itemBuy) {
			
				repositorioBuy.saveAndFlush(buy);
			c.setBuy(buy);
			repositorioItemBuy.saveAndFlush(c);
			
		}
		
		client.setFunds(client.getFunds() - buy.getValueTotal());
		
		repositorioClient.saveAndFlush(client);
		
		itemBuy = new ArrayList<>();
		buy = new Buy();

		return mv;
		}
		
		return mv2;
	
	}

	@GetMapping("/api/addQuantity/{id}/{action}")
	public String changeQuantity(@PathVariable Long id, @PathVariable Integer action) {
		new ModelAndView("api/user/cart");

		for (ItemBuy it : itemBuy) {
			if (it.getMedicine().getId().equals(id)) {
				
				if (action.equals(1)) {
					it.setQuantity(it.getQuantity() + 1);
					it.setValueTotal(0.);
					it.setValueTotal(it.getValueTotal() + (it.getQuantity() * it.getPriceUnit()));
				} else if (action == 0) {
					it.setQuantity(it.getQuantity() - 1);
					it.setValueTotal(0.);
					it.setValueTotal(it.getValueTotal() + (it.getQuantity() * it.getPriceUnit()));
				}
				break;
			}
		}

		return "redirect:/api/cart";
	}

	@GetMapping("/api/removemedicine/{id}")
	public String removemedicineCart(@PathVariable Long id) {

		for (ItemBuy it : itemBuy) {
			if (it.getMedicine().getId().equals(id)) {
				itemBuy.remove(it);
				break;
			}
		}

		return "redirect:/api/cart";
	}

	@GetMapping("/api/addCart/{id}")
	public String addCart(@PathVariable Long id) {

		Optional<Medicine> med = repositorioMedicine.findById(id);
		Medicine medicine = med.get();

		int control = 0;
		for (ItemBuy it : itemBuy) {
			if (it.getMedicine().getId().equals(medicine.getId())) {
				it.setQuantity(it.getQuantity() + 1);
				it.setValueTotal(0.);
				it.setValueTotal(it.getValueTotal() + (it.getQuantity() * it.getPriceUnit()));
				control = 1;
				break;
			}
		}
		if (control == 0) {
			ItemBuy item = new ItemBuy();
			item.setMedicine(medicine);
			item.setPriceUnit(medicine.getPrice());
			item.setQuantity(item.getQuantity() + 1);
			item.setValueTotal(item.getValueTotal() + (item.getQuantity() * item.getPriceUnit()));

			itemBuy.add(item);
		}

		return "redirect:/api/cart";
	}


	
	
	
}
