package com.dev.store.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.repositories.BuyRepositories;

@Controller
public class BuyController {
	
	@Autowired
	private BuyRepositories buyRepositories;

	@GetMapping("/api/admin/buy/list")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/admin/buy/list");
		mv.addObject("listBuy", buyRepositories.findAll());
		return mv;
	}
	

}
