package com.dev.store.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dev.store.models.Client;
import com.dev.store.repositories.ClientRepositories;
import com.dev.store.service.ReportServiceClient;
import net.sf.jasperreports.engine.JRException;

@SpringBootApplication
@RestController
public class StoreClientController {
	
	@Autowired
	private ClientRepositories clientRepositories;
	
	@Autowired
	private ReportServiceClient service;
	
	@GetMapping("/api/admin/getClient")
	public List<Client> getClient(){
		return clientRepositories.findAll();
	}

	@GetMapping("/api/admin/client/{format}")
	public String generateReport(@PathVariable String format)  throws FileNotFoundException, JRException{
		return service.exportReport(format);
	}
	


}
