package com.dev.store.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.City;
import com.dev.store.repositories.CityRepositories;
import com.dev.store.repositories.StateRepositories;

@Controller
public class CityController {
	
	@Autowired
	private CityRepositories cityRepositorio;
	
	@Autowired
	private StateRepositories stateRepositorio;
	
	
	@GetMapping("/api/admin/city/register")
	public ModelAndView register(City city) {
		ModelAndView mv =  new ModelAndView("api/admin/city/register");
		mv.addObject("city",city);
		mv.addObject("listStates",stateRepositorio.findAll());
		return mv;
	}
	
	@GetMapping("/api/admin/city/list")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/admin/city/list");
		mv.addObject("listCity", cityRepositorio.findAll());
		return mv;
	}
	
	@GetMapping("/api/admin/city/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		Optional<City> city = cityRepositorio.findById(id);
		return register(city.get());
	}
	
	@GetMapping("/api/admin/city/remove/{id}")
	public ModelAndView remove(@PathVariable("id") Long id) {
		Optional<City> city = cityRepositorio.findById(id);
		cityRepositorio.delete(city.get());
		return list();
	}
	
	@PostMapping("/api/admin/city/save")
	public ModelAndView save(@Valid City city, BindingResult result) {
		
		if(result.hasErrors()) {
			return register(city);
		}
		cityRepositorio.saveAndFlush(city);
		
		return register(new City());
	}

}
