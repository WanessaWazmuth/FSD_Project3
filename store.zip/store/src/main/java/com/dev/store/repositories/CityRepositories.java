package com.dev.store.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.store.models.City;

public interface CityRepositories extends JpaRepository<City, Long> {

}
