package com.dev.store.controller;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ImagemController {

	private static String pathImages = "C:\\Users\\Wanessa_Wazmuth\\Documents\\Imagens";


	@GetMapping("/api/admin/medicine/showImage/{image}")
	@ResponseBody
	public byte[] returImage(@PathVariable("image") String image) throws IOException {
		File imageFile = new File(pathImages + image);
		if (image != null || image.trim().length() > 0) {
			System.out.println("No IF");
			return Files.readAllBytes(imageFile.toPath());
		}
		return null;
	}
}
